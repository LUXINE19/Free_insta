import requests, re, time, calendar, random, datetime, binascii, struct, base64, sys, os, pyotp, json, uuid

from colorama import Fore
from termcolor import colored
from rich.console import Console
from rich.panel import Panel
from rich.columns import Columns
# from rich import print
from fake_email import Email
from bs4 import BeautifulSoup as bs
from urllib.parse import quote_plus
import re,os,sys,bs4,json,random,time,datetime,requests,string
from datetime import datetime
from fake_email import Email
from faker import Faker
from data import *
from Terminalize.Styles import style_terminal
import time,datetime
from Penyimpanan.Banner import Terminal
from bs4 import BeautifulSoup as bs
from run import Main2
from rich import print as prints
from rich.tree import Tree
import cloudscraper
import subprocess

from rich.panel import Panel
R = '\033[91;1m' 
G = '\033[92;1m'
R = '\033[31;1m'
RED = '\x1b[38;5;46m'
G = '\033[32;1m'
Y = '\033[33;1m'
B = '\033[34;1m'
M = '\033[35;1m'
C = '\033[36;1m'
R = '{RED}' 
XXXX = '\x1b[38;5;123m'
P = C
XXX = '\x1b[38;5;14m'
#from Cryptodome import Random
#from Cryptodome.Cipher import AES
#from nacl.public import PublicKey, SealedBox

HeadersChangPicture = lambda token, p_pic_s : {"Host": "www.instagram.com", "Accept": "*/*", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36", "Accept-Language": "en-US,en;q=0.5", "Accept-Encoding": "gzip, deflate, br", "Referer": "https://www.instagram.com", "X-CSRFToken": str(token),"X-Instagram-AJAX": "1013618137", "X-Requested-With": "XMLHttpRequest", "Content-Length": str(p_pic_s),"DNT": "1", "Connection": "keep-alive",}

def clear(): os.system('cls' if 'win' in sys.platform.lower() else 'clear')

from datetime import datetime
pilih = '╰─>'
def logonya():
	Terminal().Banner_Instagram()
	Console(width = 65, style = f"{style_terminal}").print(Panel(f"[grey50]Masukan Password Untuk Akun Yang Akan Dibuat", title = f"[white]• [green]SIMPLE CREATE INSTAGRAM [white]•", subtitle = "╭─────", subtitle_align = "left"))
#	pwd = "cicak123"
	pwd = input(f'{pilih} ')
	Console(width = 65, style = f"{style_terminal}").print(Panel(f"[grey50]Hiraukan Saja Orang Orang Yang Menjauhkan Mu Diwaktu Kamu Lagi Susah & Hiraukan Saja Orang Yang Sering Berkata Kita Mustahil Melakukanya Cukup Buktikan Saja!!", title = f"[white]• [green]PEMBERITAHUAN [white]•", subtitle = "╭─────", subtitle_align = "left"))
#	Console(width = 65, style = f"{style_terminal}").print(Panel(f"[grey50]Masukan Email Sementara ", title = f"[white]• [green]EMAIL[white]•", subtitle = "╭─────", subtitle_align = "left"))
	while True:
		lo = instagram(pwd)
		lo.getname()
		lo.GetData()
		lo.get_email_10minute()
		lo.step1()
		lo.step2()
		lo.step3()
	#	lo.jeda(3, 'OTP')
		lo.get_code_10minutemail()
		lo.step4()
		lo.step5()
		lo.step6()
		lo.step7()
		lo.step8()
		lo.step9()
# Fungsi untuk mengonversi objek datetime ke string
import http.client
import json
import time
import re  # Untuk regular expression
TOKEN=[]
import http.client
import json
import time
import re
head_email= {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','Accept-Encoding':'gzip, deflate','Accept-Language':'en-US,en;q=0.9','Pragma':'akamai-x-cache-on, akamai-x-cache-remote-on, akamai-x-check-cacheable, akamai-x-get-cache-key, akamai-x-get-extracted-values, akamai-x-get-ssl-client-session-id, akamai-x-get-true-cache-key, akamai-x-serial-no, akamai-x-get-request-id,akamai-x-get-nonces,akamai-x-get-client-ip,akamai-x-feo-trace','Sec-Ch-Ua':'','Sec-Ch-Ua-Mobile':'?1','Sec-Ch-Ua-Platform':'','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (Linux; Android 11; vivo 1918 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.0000.00 Mobile Safari/537.36'}
import http.client
import json
import time
import re
def GetEmail():
  name = random.choice(['syarif','atsuna','mawar','maghfiroh','uuz','romlah'])
  nam = name.lower().replace(' ','')
  jam = str(datetime.now().strftime("%X")).replace(':','')
  ran = str(random.randrange(1000,10000))
  dom = random.choice(['fexbox.org','chitthi.in','fextemp.com','any.pink','merepost.com'])
  email = f'{nam}{ran}{jam}@{dom}'
  print(email)
  return(email)

def GetCode(email):
    url = f'https://tempmail.plus/api/mails?email={email}'
    
    try:
        req = requests.get(url, headers=head_email).json()
        
        if req.get('result') and req.get('mail_list'):
            subject = req['mail_list'][0]['subject']
            code = re.search(r'\b\d{5,6}\b', subject)  # Cari kode 5 atau 6 digit
            
            if code:
                return code.group()  # Return hanya kodenya
            
        return None  # Return None jika tidak ada kode
        
    except Exception as e:
        print(f"Error: {e}")
        return None

class FakeEmail:
    def __init__(self) -> None:
        self.conn = http.client.HTTPSConnection("one-time-temp-email-for-quick-sign-ups-verifications.p.rapidapi.com")
        self.headers = {
            'x-rapidapi-key': "8941dcfe44msh929cc46703bc173p1d16adjsn73f90a16b83e",
            'x-rapidapi-host': "one-time-temp-email-for-quick-sign-ups-verifications.p.rapidapi.com",
            'Content-Type': "application/json"
        }

    # Fungsi untuk mendapatkan email sementara
    def emailya(self) -> str | bool:
        try:
            self.conn.request("GET", "/create_random_maibox", headers=self.headers)
            res = self.conn.getresponse()
            data = res.read()
            email_data = json.loads(data.decode("utf-8"))
            email = email_data.get("email")
            print(f"Email baru: {email}")
            return email
        except Exception as e:
            print(f"Error saat mendapatkan email: {e}")
            return False

    # Fungsi untuk mendapatkan kode 6 digit dari email
    def get_messages(self, email: str) -> str | None:
        time.sleep(5)  # Menunggu beberapa detik untuk memastikan email diterima
        try:
            self.conn.request("GET", f"/get_emails_by_address?email={email}&limit=100", headers=self.headers)
            res = self.conn.getresponse()
            data = res.read()
            messages_data = json.loads(data.decode("utf-8"))
      #      print(messages_data)
            
            if messages_data:
                print(f"Pesan yang diterima di {email}:")
                for message in messages_data:
                    print(f"Subject: {message['subject']}")
                
                content = messages_data[0]['text']
                match = re.search(r'\b\d{6}\b', content)
                if match:
                    return match.group()
                else:
                    print("Kode 6 digit tidak ditemukan.")
                    return None
            else:
                print("Tidak ada pesan di inbox.")
                return None
        except Exception as e:
            print(f"Error saat mendapatkan pesan: {e}")
            return None

# Contoh penggunaan
FAE = FakeEmail()
TOKEN=[]
D="[bold #666666]"
#input=Console().input
sys.stdout.write('\x1b]2; SACF | LUXINE CREATE\x07')
from bs4 import BeautifulSoup as bsp
import time
class InstaBot:
    def __init__(self):
        self.acak1 = 'abcdefghijklmnopqrstuvwxyz'

    def email(self):
        """Membuat email acak di InboxKitten."""
        email_prefix = ''.join(random.choices(self.acak1, k=8))
        email = f"{email_prefix}{random.randint(1, 9999)}@inboxkitten.com"
        return email

    def kode(self, email):
        """Cek apakah ada pesan masuk di email yang dibuat."""
        inbox_url = f"https://inboxkitten.com/api/v1/mail/list?recipient={email}"
        response = requests.get(inbox_url).text

        # Ambil key dan region dari email masuk
        key = re.findall('"key":"(.*?)"', response)
        region = re.findall('"region":"(.*?)"', response)

        if key and region:
            return self.get_verification_code(region[0], key[0])
        return None

    def get_verification_code(self, region, key):
        """Mengambil isi pesan dari email yang masuk."""
        url = 'https://inboxkitten.com/api/v1/mail/getHtml'
        params = {'region': region, 'key': key}
        headers = {
            'user-agent': 'Mozilla/5.0 (Linux; Android 10)',
            'accept': 'text/html,application/xhtml+xml,application/xml'
        }

        req = requests.get(url, params=params, headers=headers)
        sdr = bsp(req.text, 'html.parser')

        # Cari kode verifikasi dalam pesan
        for yxz in sdr.find_all('td'):
            match = re.findall(r'<td style=".*?">(\d+)</td>', str(yxz))
            if match:
                return match[0]
        return None
bot = InstaBot()
def banner():
    os.system("clear")
    print(f"{W}<{R}•{W}> FACEBOOK AUTO CREATE SIMPLE")
    print(f"{W}<{R}•{W}> CODED :- {G}RIDWAN")
    print(f"{W}———————————————————————————————")

def linex():
    print(f"{W}———————————————————————————————")


import requests
import random
import re
from datetime import datetime

BASE_URL = "https://api.temp-mail.solutions"

# Generate Email
def GetEmail():
    response = requests.get(f"{BASE_URL}/api/email")
    
    # Debug: Cetak respons untuk memastikan formatnya benar
  #  print("Response JSON:", response.text)
    
    if response.status_code == 200:
        try:
            data = response.json().get("data", {})  # Ambil sebagai dictionary, bukan list
            if "email" in data and "password" in data and "token" in data:
                email, password, token = data["email"], data["password"], data["token"]
                #print(f"Generated Email: {email}")
                return email, password, token
            else:
                print("Error: Data tidak lengkap dalam respons API.")
                return None, None, None
        except Exception as e:
            print("Error parsing JSON:", e)
            return None, None, None
    else:
        print(f"Failed to generate email. Status Code: {response.status_code}")
        return None, None, None

# Cek isi email dan ambil kode verifikasi
def GetCode(token):
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/api/mail", headers=headers)
    
    # Debug: Cetak respons untuk memastikan isinya
   # print("Mail Response JSON:", response.text)
    
    if response.status_code == 200:
        mails = response.json().get("data", [])
        if mails:
            subject = mails[0]["subject"]
            code = re.search(r"\b\d{5,6}\b", subject)
            if code:
                return code.group()  # Return hanya kodenya
    return None

# Eksekusi
import requests
import time
# Base URL for the API
base_url = "https://tacomail.de/api/v1"

# Function to generate an email
def emaill():
    # Fetch a random username
    response = requests.get(f"{base_url}/randomUsername")
    if response.status_code == 200:
        username = response.json()['username']
        # Fetch available domains
        domains = requests.get(f"{base_url}/domains").json()
        # Generate email using the random username and first available domain
        return f"{username}@{domains[0]}" if domains else None
    return None

# Function to get the verification code
import re

# Function to get the verification code
def kodee(email):
    # Fetch the last 10 mails from the inbox
    response = requests.get(f"{base_url}/mail/{email}")
   # print(response.text)
    if response.status_code == 200:
        mails = response.json()
        # Check for the verification code in the body of the email
        for mail in mails:
            if 'body' in mail and 'text' in mail['body']:
                body = mail['body']['text']
                # Extracting the 6-digit code from the body
                match = re.search(r'\b\d{6}\b', body)  # Match exactly 6 digits
                if match:
                    return match.group()
    return None

import requests
import re
import random
import string

def tutor():
    email_prefix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    return f"{email_prefix}@mailforspam.com"

import requests
import re

def kodees(email):
    username = email.split('@')[0]
    url = f"https://www.mailforspam.com/mail/{username}"
    
    response = requests.get(url)
  #  print(response.text)
    if response.status_code == 200:
        vod = re.findall(r'(\b\d{6}\b) adalah kode Instagram Anda', response.text)
        if vod:
            return vod[0]  # Mengembalikan kode pertama langsung
    return "Kode tidak ditemukan"

def nama():
	fake = Faker("id_ID")
	depan = fake.first_name_female()
	belakang = fake.first_name_female()
	nomor = random.randint(18,29)
	na = f"{depan}_{belakang}{nomor}".lower()
	return na
class instagram:
    def __init__(self, pwd):
        self.ses = requests.Session()
        self.pnw = pwd
        self.head_email = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','Accept-Encoding':'gzip, deflate','Accept-Language':'en-US,en;q=0.9','Pragma':'akamai-x-cache-on, akamai-x-cache-remote-on, akamai-x-check-cacheable, akamai-x-get-cache-key, akamai-x-get-extracted-values, akamai-x-get-ssl-client-session-id, akamai-x-get-true-cache-key, akamai-x-serial-no, akamai-x-get-request-id,akamai-x-get-nonces,akamai-x-get-client-ip,akamai-x-feo-trace','Sec-Ch-Ua':'','Sec-Ch-Ua-Mobile':'?1','Sec-Ch-Ua-Platform':'','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (Linux; Android 11; vivo 1918 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.0000.00 Mobile Safari/537.36'}
        
        version = random.randint(8, 12)
        build1  = random.randint(189999, 201217)
        build2  = random.randint(1, 9)
        ver1 = random.randint(90, 299)
        ver2 = random.randint(3800, 5000)
        self.bio = random.choice(["Hello Semua","Selamat Malam","Selamat Siang","Selamat Sore","Sehat Selalu","Berkah Selalu","Alhamdulilah"])
        self.eemail, self.password, self.token = GetEmail()
        ver3 = random.randint(100, 299)
        self.headers = {'Host': 'www.instagram.com','X-Ig-Www-Claim': '0','X-Requested-With': 'XMLHttpRequest','Sec-Ch-Prefers-Color-Scheme': 'dark','X-Ig-App-Id': '1217981644879628','User-Agent': 'Mozilla/5.0 (Linux; Android {}; DT{}C; Build/RKQ1.{}.00{}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{}.0.{}.{} Mobile Safari/537.36 Firefox-KiToBrowser/{}.0'.format(version, ver2, build1, build2, ver1, ver2, ver3, ver1),'Content-Type': 'application/x-www-form-urlencoded','Accept': '*/*','X-Asbd-Id': '129477','Origin': 'https://www.instagram.com','Sec-Fetch-Site': 'same-origin','Sec-Fetch-Mode': 'cors','Sec-Fetch-Dest': 'empty','Referer': 'https://www.instagram.com/accounts/signup/email/','Accept-Encoding': 'gzip, deflate','Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7','Priority': 'u=1, i'}

    
    def jeda(self, x, msg):
        timers = int(x)
        while timers > 0:
            print(f'\rMenunggu {msg} Dalam {timers} Detik...  ', end='\r')
            time.sleep(1)
            timers -= 1

    def getname(self):
        self.username = nama()
        self.names = nama()
      #  print(self.names)
        #print()

    def Code(self):
    	self.content = PanggillJs().Work(True,True)
    	print('code found', self.content)
    	return self.content[0]
    def get_email_10minute(self):
        #
        #sf = self.pnw
       # self.email,self.inbox_id,self.token = create_inbox()
        self.email = tutor()
       # self.email = GetEmail()
    def get_code_10minutemail(self):
        time.sleep(5)
        emailku = self.email
        self.code = kodees(emailku)
   #  2   print(self.code)
   #   time.sleep
      #  time.sleep(10)
      # self.code =GetCode(emailku)
      #  print(self.code)
      #  self.code = self.Code() 
    def GetData(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Alt-Used': 'www.instagram.com',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Priority': 'u=0, i',
        }

        response = self.ses.get('https://www.instagram.com/', headers=headers).text
        self.cookies = ";".join([key+"="+value.replace('"','') for key, value in self.ses.cookies.get_dict().items()])
        match = re.search(r'"InstagramPasswordEncryption",\[\],{"key_id":"(\d+)","public_key":"(.*?)","version":"(\d+)"', str(response))
        if match: self.key_id, self.pub_key, self.version = match.group(1), match.group(2), match.group(3)
        self.clienid = re.search(r'"machine_id":"(.*?)"',str(response)).group(1)
        self.csrf    = re.search(r'csrftoken=(.*?);', str(self.cookies)).group(1)
        self.claim   = re.search(r'"claim":"(.*?)"', str(response)).group(1)
    
    def encrypt_password(self):
        self.password = self.pnw
        enpas = '#PWD_INSTAGRAM:0:{}:{}'.format(str(time.time())[:10], self.password)
        return enpas
    
    def step1(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'X-Csrftoken': self.csrf,
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Asbd-Id': '129477',
            'X-Requested-With': 'XMLHttpRequest',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'Accept': '*/*',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'X-Ig-Www-Claim': self.claim,
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/email/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        response = self.ses.get('https://www.instagram.com/api/v1/web/login_page/', cookies={'cookie': self.cookies}, headers=headers, allow_redirects=True).text
   #     print(response)
        #print()

    def step2(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/email/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }
        
        data = {'email': self.email}

        response = self.ses.post('https://www.instagram.com/api/v1/web/accounts/check_email/', cookies={'cookie': self.cookies}, data=data, headers=headers, allow_redirects=True).text
        #print(response)
       # print()

    def step3(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/email/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'device_id': self.clienid,
            'email': self.email,
        }

        response = self.ses.post('https://www.instagram.com/api/v1/accounts/send_verify_email/', cookies={'cookie': self.cookies}, data=data, headers=headers, allow_redirects=True).text
      #  print(response)
        #print()

    def step4(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/emailConfirmation/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'code': self.code,
            'device_id': self.clienid,
            'email': self.email,
        }

        response = self.ses.post('https://www.instagram.com/api/v1/accounts/check_confirmation_code/', cookies={'cookie': self.cookies}, data=data, headers=headers, allow_redirects=True).json()
        if response.get("status") == "ok" and "signup_code" in response:
        	self.konfircode = response["signup_code"]
        else:
            while True:
            	pwd = 'boya123@'
            	lo = instagram(pwd)
            	lo.getname()
            	lo.GetData()
            	lo.get_email_10minute()
            	lo.step1()
            	lo.step2()
            	lo.step3()
            	lo.get_code_10minutemail()
            	lo.step4()
            	lo.step5()
            	lo.step6()
            	lo.step7()
            	lo.step8()
            	lo.step9()
            print("Gagal verifikasi kode, mengulang dari awal...")
            return 
        
      #  print(response)
        #self.konfircode = response["signup_code"]

    def step5(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/name/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'enc_password': self.encrypt_password(),
            'email': self.email,
            'failed_birthday_year_count': '{}',
            'first_name': self.names,
            'username': '',
            'seamless_login_enabled': '1',
            'use_new_suggested_user_name': 'true',
        }

        response = self.ses.post('https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/', cookies={'cookie': self.cookies}, data=data, headers=headers, allow_redirects=True).text
        #print(response)
     #   print()

    def step6(self):
        self.day = str(random.randint(1, 25))
        self.month = str(random.randint(1, 10))
        self.year  = str(random.randint(1998, 2005))
        headers = {
            'Host': 'www.instagram.com',
            # 'Content-Length': '23',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/birthday/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'day'  : self.day,
            'month': self.month,
            'year' : self.year,
        }

        response = self.ses.post('https://www.instagram.com/api/v1/web/consent/check_age_eligibility/', cookies={'cookie': self.cookies}, data=data, headers=headers, allow_redirects=True).text
      #  print(response)
        #print()

    def step7(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/username/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {'username': self.names}

        response = self.ses.post('https://www.instagram.com/api/v1/users/check_username/', cookies={'cookie': self.cookies}, data=data, headers=headers, allow_redirects=True).json()
        # self.username = response["username_suggestions"]["suggestions"][4]
   #     print(response)
        #print()

    def step8(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '1217981644879628',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/username/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'enc_password': self.encrypt_password(),
            'day': self.day,
            'email': self.email,
            'failed_birthday_year_count': '{}',
            'first_name': self.names,
            'month': self.month,
            'username': self.username,
            'year': self.year,
            'client_id': self.clienid,
            'seamless_login_enabled': '1',
            'tos_version': 'row',
            'force_sign_up_code': self.konfircode,
            # 'extra_session_id': '5oxdc6:1he7cf:6q5g2x',
        }

        response = self.ses.post('https://www.instagram.com/api/v1/web/accounts/web_create_ajax/', cookies={'cookie': self.cookies}, data=data, headers=headers, allow_redirects=True).text
        self.cookies = ";".join([key+"="+value.replace('"','') for key, value in self.ses.cookies.get_dict().items()])
        #print(response)
        #print()

    def step9(self):
        headers = {
            'Host': 'www.instagram.com',
            'Dpr': '1.2000000000000002',
            'Viewport-Width': '718',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Dest': 'document',
            'Referer': 'https://www.instagram.com/accounts/signup/username/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=0, i',
        }

        response = self.ses.get('https://www.instagram.com/accounts/registered/', cookies={'cookie': self.cookies}, headers=headers, allow_redirects=True).text
      #  print(response)
        mauenc = self.encrypt_password()
        print("\r                                                                          ")
        user = f'{self.username}'
        pw = f'{self.pnw}'
        cok = f'{self.cookies}'
        tok = f'{self.csrf}'
        
        bio = self.bio
        email = self.email
        open(f"/sdcard/{self.pnw}.txt","a").write(f'{cok}\n')
        posting(tok,cok)
        editbio(cok, tok, bio, email)
        ssi = random.randint(2,116)
      #  filefoto = f'data/a{ssi}.jpg'
      #  upload_photo(tok, cok, user, filefoto)
        Main2(user,pw, cok)
       # follow1(cok,tok)
   #     follow2(cok,tok)
   #     komen(bio,cok)

def follow1(cok,tok):
        user_id = "3260242515"
        try:
        	

            headers = {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                'x-ig-app-id': '1217981644879628'
            }
            HD3 = {
                "Host": "www.instagram.com",
                "content-length": "108",
                "sec-ch-ua": '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                "x-ig-app-id": "1217981644879628",
                "x-ig-www-claim": "hmac.AR2bJKYJnPYmZqv19akfq13Zn4tplhuXb9TC9PwFk03Dg4v5",
                "sec-ch-ua-mobile": "?1",
                "x-instagram-ajax": "1007404816",
                "user-agent": headers['User-Agent'],
                "viewport-width": "360",
                "content-type": "application/x-www-form-urlencoded",
                "accept": "*/*",
                "x-requested-with": "XMLHttpRequest",
                "x-asbd-id": "198387",
                "sec-ch-ua-full-version-list": '"Chromium";v="110.0.5481.153", "Not A(Brand";v="24.0.0.0", "Google Chrome";v="110.0.5481.153"',
                "x-csrftoken":f'{tok}',
                "sec-ch-prefers-color-scheme": "light",
                "sec-ch-ua-platform": "Android",
                "origin": "https://www.instagram.com",
                "sec-fetch-site": "same-origin",
                "sec-fetch-mode": "cors",
                "sec-fetch-dest": "empty",
                "referer": "https://www.instagram.com/the.jpexec_/",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "cookie":f'{cok}'
            }
            Pay = {
                "container_module": "profile",
                "nav_chain": "PolarisProfileRoot:profilePage:1:via_cold_start",
                "user_id": user_id
            }
            API = requests.post(f'https://www.instagram.com/api/v1/friendships/create/{user_id}/', headers=HD3, data=Pay)
            if API.status_code == 200:
                tree = Tree('[bold white][ FOLLOW KE AKUN 1 ]')
                tree.add(f'[bold green]Sukses Follow Akun 1')
                prints(tree)
                return True
            else:
               #print('')
                print(f"Follow failed for user_id: {M}{user_id}, {P}Status code: {API.status_code}")
                return False
        except Exception as e:
            print(f"An error occurred: {e}")
            return False
def komen(bio,cok):
        headers = {
            "Content-Length": "28",
            "sec-ch-ua": '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
            "x-ig-www-claim": "hmac.AR3Ns1l82Qzp1Zs1bJNgHSW8IJK4d-1Qj7qbIM9TN1evT-XS",
            "sec-ch-ua-platform-version": '"5.0.0"',
            "x-requested-with": "XMLHttpRequest",
            "sec-ch-ua-full-version-list": '"Not)A;Brand";v="99.0.0.0", "Google Chrome";v="127.0.6533.100", "Chromium";v="127.0.6533.100"',
            "sec-ch-prefers-color-scheme": "light",
            "x-csrftoken": re.search(r'csrftoken=(.*?);', cok).group(1),
            "sec-ch-ua-platform": '"Windows"',
            "x-ig-app-id": "936619743392459",
            "sec-ch-ua-model": '""',
            "sec-ch-ua-mobile": "?0",
            "x-instagram-ajax": "1015576910",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
            "content-type": "application/x-www-form-urlencoded",
            "accept": "/",
            "x-asbd-id": "129477",
            "origin": "https://www.instagram.com",
            "sec-fetch-site": "same-origin",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "accept-encoding": "gzip, deflate, br, zstd",
            "accept-language": "id,en-US;q=0.9,en;q=0.8"
        }
        data = {"comment_text": f"{bio}"}
        try:
            response = requests.post(f"https://www.instagram.com/api/v1/web/comments/2243569220713804232/add/", headers=headers, data=data, cookies={"cookie": cok})
            response.raise_for_status()  # Raise an exception for HTTP errors
            return response.json()  # Return the JSON response
        except requests.RequestException as e:
            print(f"An error occurred: {e}")
def follow2(cok,tok):
        user_id = "70124839428"
        try:
        	

            headers = {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 5.0.1; HUAWEI GRA-L09 Build/HUAWEIGRA-L09C150B196) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36 Instagram 37.0.0.21.97 Android (21/5.0.1; 480dpi; 1080x1794; HUAWEI; HUAWEI GRA-L09; HWGRA; hi3635; hu_HU; 98288242)',
                'x-ig-app-id': '1217981644879628'
            }
            HD3 = {
                "Host": "www.instagram.com",
                "content-length": "108",
                "sec-ch-ua": '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                "x-ig-app-id": "1217981644879628",
                "x-ig-www-claim": "hmac.AR2bJKYJnPYmZqv19akfq13Zn4tplhuXb9TC9PwFk03Dg4v5",
                "sec-ch-ua-mobile": "?1",
                "x-instagram-ajax": "1007404816",
                "user-agent": headers['User-Agent'],
                "viewport-width": "360",
                "content-type": "application/x-www-form-urlencoded",
                "accept": "*/*",
                "x-requested-with": "XMLHttpRequest",
                "x-asbd-id": "198387",
                "sec-ch-ua-full-version-list": '"Chromium";v="110.0.5481.153", "Not A(Brand";v="24.0.0.0", "Google Chrome";v="110.0.5481.153"',
                "x-csrftoken":f'{tok}',
                "sec-ch-prefers-color-scheme": "light",
                "sec-ch-ua-platform": "Android",
                "origin": "https://www.instagram.com",
                "sec-fetch-site": "same-origin",
                "sec-fetch-mode": "cors",
                "sec-fetch-dest": "empty",
                "referer": "https://www.instagram.com/the.jpexec_/",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "cookie":f'{cok}'
            }
            Pay = {
                "container_module": "profile",
                "nav_chain": "PolarisProfileRoot:profilePage:1:via_cold_start",
                "user_id": user_id
            }
            API = requests.post(f'https://www.instagram.com/api/v1/friendships/create/{user_id}/', headers=HD3, data=Pay)
            if API.status_code == 200:
                print(f"\r{R}[{G}√{R}]{G} Successfully Follow : {H}{user_id}{P}")
                return True
            else:
               #print('')
                print(f"Follow failed for user_id: {M}{user_id}, {P}Status code: {API.status_code}")
                return False
        except Exception as e:
            print(f"An error occurred: {e}")
            return False
def editbio(cok, tok, bio, email):
    import requests
    import re

    header = {
        'authority': 'www.instagram.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control': 'max-age=0',
        'dpr': '1.5',
        'sec-ch-prefers-color-scheme': 'dark',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-model': '"SM-J250F"',
        'sec-ch-ua-platform': '"Android"',
        'sec-ch-ua-platform-version': '"7.1.1"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        'viewport-width': '980',
    }

    req = requests.get('https://www.instagram.com/accounts/edit/', cookies={"cookie": cok}, headers=header).text

    # Menghindari IndexError dengan menggunakan default value jika tidak ditemukan
    full_name_match = re.findall(r'"full_name":"(.*?)"', req)
    username_match = re.findall(r'"username":"(.*?)"', req)

    full_name = full_name_match[0] if full_name_match else ""
    username = username_match[0] if username_match else ""

    headers = {
        'authority': 'www.instagram.com',
        'accept': '*/*',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://www.instagram.com',
        'referer': 'https://www.instagram.com/accounts/edit/',
        'sec-ch-prefers-color-scheme': 'dark',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-model': '"SM-J250F"',
        'sec-ch-ua-platform': '"Android"',
        'sec-ch-ua-platform-version': '"7.1.1"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        'x-asbd-id': '129477',
        'x-csrftoken': f"{tok}",
        'x-ig-app-id': '1217981644879628',
        'x-ig-www-claim': 'hmac.AR14eYoEFF2NWxaAbiIIbG3rGSSgS2VCHbfRjFoPoLm-5s0z',
        'x-instagram-ajax': '1015039620',
        'x-requested-with': 'XMLHttpRequest',
    }

    data = {
        'biography': bio,
        'chaining_enabled': 'on',
        'email': email,
        'external_url': '',
        'first_name': full_name,
        'phone_number': '',
        'username': username,
    }

    res = requests.post('https://www.instagram.com/api/v1/web/accounts/edit/', cookies={"cookie": cok}, headers=headers, data=data).text

    if '"status":"ok"' in res:
        print("[ MEMASANG BIO ]\nSukses Memasang Bio")
        followig(cok, tok)

def editfbio(cok, tok, bio, email):
  #  
    header = {
      'authority': 'www.instagram.com',
      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
      'cache-control': 'max-age=0',
      'dpr': '1.5',
      'sec-ch-prefers-color-scheme': 'dark',
      'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
      'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-model': '"SM-J250F"',
      'sec-ch-ua-platform': '"Android"',
      'sec-ch-ua-platform-version': '"7.1.1"',
      'sec-fetch-dest': 'document',
      'sec-fetch-mode': 'navigate',
      'sec-fetch-site': 'none',
      'sec-fetch-user': '?1',
      'upgrade-insecure-requests': '1',
      'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
      'viewport-width': '980',
    }
  
    req= requests.get('https://www.instagram.com/accounts/edit/', cookies={"cookie":cok}, headers=header).text 
    
  
    headers = {
      'authority': 'www.instagram.com',
      'accept': '*/*',
      'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
      'content-type': 'application/x-www-form-urlencoded',
      'origin': 'https://www.instagram.com',
      'referer': 'https://www.instagram.com/accounts/edit/',
      'sec-ch-prefers-color-scheme': 'dark',
      'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
      'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-model': '"SM-J250F"',
      'sec-ch-ua-platform': '"Android"',
      'sec-ch-ua-platform-version': '"7.1.1"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
      'x-asbd-id': '129477',
      'x-csrftoken': f"{tok}",
      'x-ig-app-id': '1217981644879628',
      'x-ig-www-claim': 'hmac.AR14eYoEFF2NWxaAbiIIbG3rGSSgS2VCHbfRjFoPoLm-5s0z',
      'x-instagram-ajax': '1015039620',
      'x-requested-with': 'XMLHttpRequest',
    }
  
    data = {
      'biography': bio,
      'chaining_enabled': 'on',
      'email': email,
      'external_url': '',
      'first_name': re.findall('"full_name":"(.*?)"',str(req))[0],
      'phone_number': '',
      'username': re.findall('"username":"(.*?)"',str(req))[0],
    }
    res = requests.post('https://www.instagram.com/api/v1/web/accounts/edit/', cookies={"cookie":cok}, headers=headers, data=data).text
    if '"status":"ok"' in str(res):
    	tree = Tree('[bold white][ MEMASANG BIO ]')
    	tree.add(f'[bold green]Sukses Memasang Bio')
    	prints(tree)
    	followig(cok,tok)
  #    print(f"{P}[*] Success Bio : {H}{self.bio}{P}\n")
   #   gg = ""
    else: pass
def upload_photo(token, cookies, username, photo_path):
    headers = {
        'authority': 'www.instagram.com',
        'accept': '*/*',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://www.instagram.com',
        'referer': f'https://www.instagram.com/{username}/',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-platform': '"Linux"',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'x-asbd-id': '129477',
        'x-csrftoken': token,
        'x-ig-app-id': '936619743392459',
        'x-instagram-ajax': '1015170809',
        'x-requested-with': 'XMLHttpRequest',
    }
    
    timestamp = str(int(time.time() * 1000))
    file_size = os.path.getsize(photo_path)
    file_format = random.choice(["png", "jpeg", "jpg"])
    
    try:
        headers.update({
            'content-type': f'image/{file_format}',
            'x-entity-length': str(file_size),
            'x-entity-name': f'fb_uploader_{timestamp}',
            'x-entity-type': f'image/{file_format}',
            'x-instagram-rupload-params': json.dumps({
                "media_type": 1, "upload_id": timestamp,
                "upload_media_height": 375, "upload_media_width": 375
            }),
        })
        
        upload_url = f'https://i.instagram.com/rupload_igphoto/fb_uploader_{timestamp}'
        with open(photo_path, "rb") as picture:
            response = requests.post(upload_url, headers=headers, data=picture, cookies={"cookie": cookies}).json()
        
        if 'upload_id' in response:
            return configure_upload(response['upload_id'], token, cookies, username)
    except Exception as e:
        print(f"Error uploading photo: {e}")
    

def configure_upload(photo_id, token, cookies, username):
    try:
        headers = {
            'authority': 'www.instagram.com',
            'accept': '*/*',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://www.instagram.com',
            'referer': f'https://www.instagram.com/{username}/',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-asbd-id': '129477',
            'x-csrftoken': token,
            'x-ig-app-id': '936619743392459',
            'x-instagram-ajax': '1015170809',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        data = {
            'archive_only': 'false',
            'caption': 'ingin mencintaimu setulus hatiku',
            'source_type': 'library',
            'upload_id': photo_id,
        }
        
        response = requests.post('https://www.instagram.com/api/v1/media/configure/', 
                                 cookies={"cookie": cookies}, headers=headers, data=data).json()
        
        if 'media' in response and 'code' in response['media']:
            print('upload foto sukses')
            return response['media']['user']['profile_pic_url']
        else:
            return "Upload gagal"
    except Exception as e:
        print(f"Error configuring upload: {e}")
        return None

import requests
import random
import re

def get_userid(username):
    try:
        url = f"https://www.instagram.com/{username}/"
        response = requests.get(url)
        html = response.text
        pattern = r'"profilePage_([0-9]+)"'
        match = re.search(pattern, html)
        if match:
            return match.group(1)
        else:
            return None
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"

def follow(tok, cok, user_id):
    try:
        headers = {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "user-agent": "Instagram 313.0.0.26.328 Android (33/13; 440dpi; 1080x2269; Xiaomi; 2201123G; cupid; qcom; it_IT; 554218560)",
            "x-ig-app-id": "198387",
            "x-ig-www-claim": "hmac.AR2mkRBy3FowqfYCnGVXZ9lzqaXP6KvNtFYb9LkPI7Fq4R5S",
            "x-instagram-ajax": "1007616494",
            "x-requested-with": "XMLHttpRequest",
            "x-csrftoken": tok,
            "cookie": cok,
            "Referer": f"https://www.instagram.com/{''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))}/",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        }
        url = f"https://www.instagram.com/api/v1/friendships/create/{user_id}/"
        response = requests.post(url, headers=headers)
        response_json = response.json()
        if response_json.get("status") == "ok":
            return f"Successfully followed user {user_id}!"
        elif response_json.get("spam"):
            return "Spam detected! Instagram is limiting actions."
        elif response_json.get("message") == "login_required":
            return "Login expired! Please update your session ID."
        else:
            return "Failed to follow the user."
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"
    except ValueError:
        return "Invalid JSON response."
def followig(cok,tok):
    cokk = cok
    tokk = tok
    usernames = "ridwanxd4","ridwankamil","gue_awa303"
    usernames = [username.strip() for username in usernames]
    for username in usernames:
        user_id = get_userid(username)
        if user_id:
            print(follow(tokk, cokk, user_id))
        else:
            print(f"Gagal mendapatkan userid dari {username}")
def posting(tok,cok):
  try:
    ssi1 = random.randint(2,16)
    ssi2 = random.randint(18,71)
    ssi = random.choice([ssi1,ssi2])
    p_pic_s = f'data/a{ssi}.jpg'
    headers = {
      "Host": "www.instagram.com",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36",
      "Accept": "/",
      "Accept-Language": "en-US,en;q=0.5",
      "Accept-Encoding": "gzip, deflate, br",
      "Referer": "https://www.instagram.com",
      "X-CSRFToken": '%s'%(tok), # ganti csrftoken sesuai cookie yang valid
      "X-Instagram-AJAX": "1013618137",
      "X-Requested-With": "XMLHttpRequest",
      "Content-Length": str(p_pic_s),
      "DNT": "1",
      "Connection": "keep-alive",
    }
    files = {'profile_pic': open(p_pic_s,'rb')}
    values = {
      "Content-Disposition": "form-data",
      "name": "profile_pic",
      "filename":"profilepic.jpg",
      "Content-Type": "image/jpeg"
      }

    r = requests.post('https://www.instagram.com/accounts/web_change_profile_picture/', files=files, data=values, headers=headers, cookies={'cookie':cok}).text
    #print('-> sukses memasang profil')
   # print(' succes mena')
    return r
    #  open('Create/ok.txt','a').write(usernam+'|'+pas+'|'+coki+"\n")
  except Exception as e:
    print(e)	
if __name__ == '__main__':
    logonya()