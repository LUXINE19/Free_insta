const io = require("socket.io-client");

function Masuk() {
    const socket = io("wss://tm-app.solucioneswc.com:2053", {
        transports: ["websocket"],
        query: {
            user_token: "empty",
            visitor_token: "empty",
            email_token: "empty",
            page_type: "inbox",
            EIO: "4"
        },
        extraHeaders: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0",
            "Accept": "*/*",
            "Accept-Language": "id,en-US;q=0.7,en;q=0.3",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Sec-WebSocket-Version": "13",
            "Origin": "https://tempmail.ninja",
            "Sec-WebSocket-Extensions": "permessage-deflate",
            "Connection": "keep-alive, Upgrade",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "websocket",
            "Sec-Fetch-Site": "cross-site",
            "Pragma": "no-cache",
            "Cache-Control": "no-cache",
            "Upgrade": "websocket"
        }
    });
    socket.on('initialize_app', (x) => {
        const token = x.visitor_token;
        const email = x.email_address;
        const expre = x.email_expiration_date
        console.log(`Email : ${email}|${token}`)
        console.log("--------------------------------------");

    })
    
    socket.on("disconnect", () => console.log("Koneksi terputus!"));
    socket.on("connect_error", (err) => console.error("Koneksi gagal:", err.message));


}
function GetMessage(token) {

    const socket = io("wss://tm-app.solucioneswc.com:2053", {
        transports: ["websocket"],
        query: {
            user_token: "empty",
            visitor_token: token,
            email_token: "empty",
            page_type: "inbox",
            EIO: "4"
        },
        extraHeaders: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0",
            "Accept": "*/*",
            "Accept-Language": "id,en-US;q=0.7,en;q=0.3",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Sec-WebSocket-Version": "13",
            "Origin": "https://tempmail.ninja",
            "Sec-WebSocket-Extensions": "permessage-deflate",
            "Connection": "keep-alive, Upgrade",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "websocket",
            "Sec-Fetch-Site": "cross-site",
            "Pragma": "no-cache",
            "Cache-Control": "no-cache",
            "Upgrade": "websocket"
        }
    });

    socket.on("connect", () => {
        console.log("Terhubung ke WebSocket!");

        setInterval(() => {
            socket.emit("get_email_messages", ["inbox"]);
        }, 5000);
    });

    socket.on("new_message_notify", (data) => {
        if (data.email_message) {
            const { id, date, sender, subject } = data.email_message;
            console.log(`📩 ID: ${id}`);
            console.log(`📅 Tanggal: ${date}`);
            console.log(`📨 Dari: ${sender.text}`);
            console.log(`📜 Subjek: ${subject}`);
            console.log("--------------------------------------");
        }
    });
    socket.on("disconnect", () => console.log("Koneksi terputus!"));
    socket.on("connect_error", (err) => console.error("Koneksi gagal:", err.message));



}
const biji = process.argv
if(biji[2] === 'email'){Masuk()}
else{GetMessage(biji[3])}
