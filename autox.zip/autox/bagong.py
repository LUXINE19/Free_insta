import subprocess
import re

class PanggillJs:
    def __init__(self):
        self.token = None  # Simpan token sebagai string

    def Work(self, kode=False, ambil_pesan=False):
        biji = 'email' if not kode else 'biji2'
        if ambil_pesan:
            if self.token:
                self.token = self.token.strip()  # Pastikan token bersih dari spasi/tanda newline
            else:
                print("❌ Error: Token masih kosong sebelum dikirim ke main.js!")
                return None

        attr = ["node", "main.js", biji] if not ambil_pesan else ["node", "main.js", biji, self.token]

        print(f"📡 Menjalankan: {' '.join(attr)}")  # Debug perintah yang dijalankan

        process = subprocess.Popen(attr, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        for line in process.stdout:
            line = line.strip()
            print(f"🔍 Output JS: {line}")  # Debug output dari main.js

            if kode:
                kode_verifikasi = re.findall(r'\b(\d{6})\b', line)  # Ambil kode 6 digit
                if kode_verifikasi:
                    return kode_verifikasi[0]

            else:
                hasil = re.findall(r'Email : (.*?)\|(.*)', line)
                if hasil:
                    email, token = hasil[0]
                    email, token = email.strip(), token.strip()  # Bersihkan dari spasi/tanda newline
                    print('✅ Email:', email)
                    print('🔑 Token:', token)
                    self.token = token  # Simpan token dengan bersih
                    print(f"🔍 Token Disimpan: {self.token}")
                    return email

        process.wait()

        if not self.token:
            print("❌ Error: Token masih kosong!")

        for line in process.stderr:
            print(f"❗ Error JS: {line.strip()}")  # Debug error dari main.js

# Jalankan script
lo = PanggillJs()
email = lo.Work()
jdb = input('cek kode ')  # Ambil email dan token
if email:
    kode_verifikasi = lo.Work(True, True)  # Ambil kode verifikasi
    print("📩 Kode Verifikasi IG:", kode_verifikasi)
