from src.dang import * 
from src.prox import *
from data import *
from run import Main2

cp = 0 
ok = 0


def tunggu(t):
  for x in range(t+1):
    print('\r[*] [OK:%s][CP:%s] Tunggu %s detik            '%(ok,cp,str(t)), end='')
    sys.stdout.flush()
    t -= 1
    if t == 0: break 
    else: time.sleep(1)
 # print('\r' + ' ' * 50 + '\r', end="")  # Clear the countdown line after completion
#user = open('ua.txt','r').read().splitlines()
user = open('ua.txt','r').read().splitlines()
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
}

def get_ese_email():
    url = "http://ese.kr/?pb=6549"
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        match = re.search(r'<input type="search" name="mailbox" value="(.*?)"', response.text)
        if match:
            return match.group(1)
    except requests.RequestException:
        pass
    return "err"

def get_ese_mail_code(email):
    url = "http://ese.kr/"
    data = {
        "mail_id": "",
        "mail_mode": "text",
        "lang": "en",
        "mailbox": email
    }
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    
    try:
        response = requests.post(url, headers=headers, data=data)
        response.raise_for_status()
        
        # Perbaikan regex untuk menangkap kode lebih fleksibel
        match = re.search(r'no-reply@mail.instagram.com.*?<a href="#">(\d{6}) adalah kode Instagram Anda</a>', response.text, re.DOTALL)
        if match:
            return match.group(1)
    except requests.RequestException:
        pass
def clear():
  os.system("clear")
import requests
import time
ses = requests.Session()

headers = {
    'authority': 'temporary-mail-generator.vercel.app',
    'accept': '*/*',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'referer': 'https://temporary-mail-generator.vercel.app/',
    'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36',
}
def emailp():
    """Membuat email sementara dan mengembalikan email serta token."""
    url = 'https://temporary-mail-generator.vercel.app/api/create-basic-inbox'
    res = ses.get(url, headers=headers).json()
    print(res)
    return res.get('address'), res.get('token')


def inbox(token):
    """Memeriksa pesan masuk berdasarkan token dan mencari kode verifikasi."""
    url = f'https://temporary-mail-generator.vercel.app/api/check-inbox/{token}'
    res = ses.get(url, headers=headers).json()
    print(res)
    if res and isinstance(res, dict) and "emails" in res:
        emails = res["emails"]
        
        if emails:
            for email in emails:
                subject = email.get("subject", "")
                body = email.get("html", "")

                # Cari kode di subject atau body HTML
                code = re.search(r'\b\d{5,6}\b', subject) or re.search(r'\b\d{5,6}\b', body)
                if code:
                    return code.group()  # Ambil kode verifikasi
                

from bs4 import BeautifulSoup as bsp
import time
class InstaBot:
    def __init__(self):
        self.acak1 = 'abcdefghijklmnopqrstuvwxyz'

    def email(self):
        """Membuat email acak di InboxKitten."""
        email_prefix = ''.join(random.choices(self.acak1, k=8))
        email = f"{email_prefix}{random.randint(1, 9999)}@inboxkitten.com"
        return email

    def kode(self, email):
        """Cek apakah ada pesan masuk di email yang dibuat."""
        inbox_url = f"https://inboxkitten.com/api/v1/mail/list?recipient={email}"
        response = requests.get(inbox_url).text

        # Ambil key dan region dari email masuk
        key = re.findall('"key":"(.*?)"', response)
        region = re.findall('"region":"(.*?)"', response)

        if key and region:
            return self.get_verification_code(region[0], key[0])
        return None

    def get_verification_code(self, region, key):
        """Mengambil isi pesan dari email yang masuk."""
        url = 'https://inboxkitten.com/api/v1/mail/getHtml'
        params = {'region': region, 'key': key}
        headers = {
            'user-agent': 'Mozilla/5.0 (Linux; Android 10)',
            'accept': 'text/html,application/xhtml+xml,application/xml'
        }

        req = requests.get(url, params=params, headers=headers)
        sdr = bsp(req.text, 'html.parser')

        # Cari kode verifikasi dalam pesan
        for yxz in sdr.find_all('td'):
            match = re.findall(r'<td style=".*?">(\d+)</td>', str(yxz))
            if match:
                return match[0]
        return None
bot = InstaBot()
import requests
from bs4 import BeautifulSoup
import time
import random
import string
import re

# URL Base sute.jp
BASE_URL = "https://sute.jp"

def buat_email():
    """Membuat email sementara di sute.jp dengan session baru setiap kali dipanggil."""
    while True:
        # Buat session baru supaya cookies fresh setiap kali buat email
        global session
        session = requests.Session()

        signup_url = f"{BASE_URL}/signup"
        response = session.get(signup_url)
        soup = BeautifulSoup(response.text, "html.parser")

        # Ambil CSRF token
        csrf_meta = soup.find("meta", {"name": "csrf-token"})
        if not csrf_meta:
            print("[X] Gagal mendapatkan CSRF token. Coba ulang...")
            time.sleep(3)
            continue

        csrf_token = csrf_meta["content"]

        # Generate username acak (6 karakter)
        username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))

        data = {
            "utf8": "✓",
            "authenticity_token": csrf_token,
            "guest[login]": username,
        }

        headers = {"Referer": signup_url, "Origin": BASE_URL}
        response = session.post(signup_url, data=data, headers=headers)

        if "メールアドレスを作成しました" in response.text:
            email = f"{username}@sute.jp"
            print(f"[✓] Email berhasil dibuat: {email}")
            return email  # Return hanya email, session tetap global
        else:
            print("[X] Gagal membuat email. Coba ulang...")
            time.sleep(3)

def ceks():
    """Cek inbox untuk mencari kode verifikasi dari Instagram sesuai email terakhir yang dibuat"""
    inbox_url = f"{BASE_URL}/inbox"

    for _ in range(10):  # Coba 10 kali (total 50 detik)
        response = session.get(inbox_url)
        if response.status_code != 200:
            print("[X] Gagal mengakses inbox.")
            return None

        soup = BeautifulSoup(response.text, "html.parser")
        messages = soup.find_all("a", class_="unread")

        for msg in messages:
            subject = msg.find("span", class_="subject")

            if subject and "kode" in subject.text:
                email_url = BASE_URL + msg["href"]
                email_response = session.get(email_url)

                if email_response.status_code == 200:
                    email_soup = BeautifulSoup(email_response.text, "html.parser")
                    match = re.search(r"\b\d{6}\b", email_soup.text)

                    if match:
                        print(f"[✓] Kode Instagram: {match.group(0)}")
                        return match.group(0)

        time.sleep(5)

    print("[X] Tidak menemukan email verifikasi Instagram.")
    return None
import random
import requests
import time
import re
TOKEN=[]
class TempMail:
    def __init__(self):
        self.session = requests.Session()
        self.base_url = "https://email.vwh.sh"
        self.headers = {
            'accept': 'application/json',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36',
        }
        self.email = self._generate_email()

    def _generate_email(self):
        """Generate temporary email"""
        abc = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))
        abc1 = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))
        return f"{abc}-{abc1}@vwh.sh"

    def emailnya(self):
        """Return the generated email"""
        return self.email

    def kodenya(self):
        """Retrieve and return the 6-digit verification code"""
        time.sleep(5)  # Tunggu 5 detik supaya email masuk

        email_endpoint = f"{self.base_url}/api/email/{self.email}"
        response = self.session.get(email_endpoint, headers=self.headers)

        if response.status_code == 200 and response.json():
            messages = response.json()
            inbox_id = messages[0]['id']

            message_endpoint = f"{self.base_url}/api/inbox/{inbox_id}"
            response = self.session.get(message_endpoint, headers=self.headers)

            if response.status_code == 200:
                content = response.json().get('textContent', '')
                code_match = re.search(r'\b\d{6}\b', content)  # Cari kode 6 digit

                if code_match:
                    return code_match.group(0)
        
        return None  # Jika tidak ditemukan

# Contoh penggunaan
najay = TempMail()
import re
import random
import requests
import time

class TempMail:
    def __init__(self):
        self.session = requests.Session()
        self.base_url = "https://email.vwh.sh"
        self.headers = {
            'accept': 'application/json',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36',
        }
        self.refresh_email()  # Buat email baru saat pertama kali

    def _generate_email(self):
        """Generate temporary email"""
        abc = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))
        abc1 = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))
        return f"{abc}-{abc1}@vwh.sh"

    def refresh_email(self):
        """Generate new email and update it"""
        self.email = self._generate_email()
        print(f"Generated New Email: {self.email}")  # Debugging

    def emailnya(self):
        """Return the current email"""
        return self.email

    def kodenya(self):
        """Retrieve and return the 6-digit verification code"""
        time.sleep(5)  # Tunggu 5 detik supaya email masuk

        email_endpoint = f"{self.base_url}/api/email/{self.email}"
        response = self.session.get(email_endpoint, headers=self.headers)

        if response.status_code == 200 and response.json():
            messages = response.json()
            inbox_id = messages[0]['id']

            message_endpoint = f"{self.base_url}/api/inbox/{inbox_id}"
            response = self.session.get(message_endpoint, headers=self.headers)

            if response.status_code == 200:
                content = response.json().get('textContent', '')
                code_match = re.search(r'\b\d{6}\b', content)  # Cari kode 6 digit

                if code_match:
                    return code_match.group(0)
        
        return None  # Jika tidak ditemukan

# Contoh penggunaan
pp = TempMail()
def Username(apasi):
  dev = log()
  pp.refresh_email()
  mail = pp.emailnya()
  print(mail)
  name = Names()
  ua = random.choice(user)
  Post = POST()
  try:
    data = {
      'email': '',
      'first_name': name,
      'client_id': dev,
      'seamless_login_enabled': '1',
      'opt_into_one_tap': 'false',
    }
    pos = requests.post("https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/", data=data, headers=Post).text 
    print(pos)
    js = json.loads(pos)
    #print(js)
    if "username_suggestions" in js:
      respon = js["username_suggestions"]
      step1(mail,name,respon,dev,Post,ua,apasi)
    else:
      sys.exit(1)
  except Exception as e:
    print(e)
  
def step1(mail,name,respon,dev,Post,ua,apasi):
  pas = apasi
  try:
    assword = apasi
    enpas = '#PWD_INSTAGRAM:0:{}:{}'.format(str(time.time())[:10], assword)
    data = {
      'enc_password': enpas,
      'email': mail,
      'first_name': name,
      'username': respon[0],
      'client_id': dev,
      'seamless_login_enabled': '1',
      'opt_into_one_tap': 'false',
    }
    pos = requests.post("https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/",headers=Post,data=data, allow_redirects=False).text 
    js = json.loads(pos)
    print(pos)
  #  print(js)
  except Exception as e:
    print(e)
  ttl(mail,name,respon,dev,pas,Post,ua)

def ttl(mail,name,respon,dev,pas,Post,ua):
  day  = random.randint(1,29)
  bln = random.randint(1,12)
  thn = random.choice(['2000','2001','2002','2003','2004'])
  try:
    data = {
      'day': day,
      'month': bln,
      'year': thn
    }
    pr = requests.post('https://www.instagram.com/api/v1/web/consent/check_age_eligibility/',headers=Post, data=data).text 
    jsk = json.loads(pr)
   # print(js)
  except Exception as e:
    print(e)
  Code(mail,name,respon,dev,pas,day,bln,thn,Post,ua)
def Code(mail,name,respon,dev,pas,day,bln,thn,Post,ua):
  try:
    data = {
      'device_id': dev,
      'email': mail
    }
    ps = requests.post("https://www.instagram.com/api/v1/accounts/send_verify_email/",headers=Post,data=data).text 
    jsb = json.loads(ps)
    time.sleep(5)
    topic = pp.kodenya()
    print(topic)
  except Exception as e:
    print(e)
  confirm(mail,name,respon,topic,dev,pas,day,bln,thn,Post,ua)
  
  
def confirm(mail,name,respon,topic,dev,pas,day,bln,thn,Post,ua):
  try:
    
    data = {
      'code': topic,
      'device_id': dev,
      'email': mail
    }
    pk = requests.post("https://www.instagram.com/api/v1/accounts/check_confirmation_code/",headers=Post, data=data).text 
    jh = json.loads(pk)
    
    if 'signup_code' in jh:
      sign_up = jh["signup_code"]
      Create(mail,name,respon,sign_up,dev,pas,day,bln,thn,Post,ua)
    else: 
      sys.exit(1)
  except Exception as e:
    print(e)
  
def Create(mail,name,respon,sign_up,dev,pas,day,bln,thn,Post,ua):
  global ok, cp
  usernam = respon[0]
  data = {
    'enc_password': '#PWD_INSTAGRAM_BROWSER:0:%s:%s'%(round(time.time()),pas),
    'day': day,
    'email': mail,
    'first_name': name,
    'month': bln,
    'username': usernam,
    'year': thn,
    'client_id': dev, 
    'seamless_login_enabled': '1',
    'tos_version': 'row',
    'force_sign_up_code': sign_up
  }
  
  pos = requests.post("https://www.instagram.com/api/v1/web/accounts/web_create_ajax/",headers=Post, data=data,allow_redirects=True)
 # print(pos.text)
  if 'user_id' in str(pos.text):
    cok = str(pos.cookies)
    tok = re.findall('csrftoken=([^ ]+)',cok)[0]
    cokie = re.findall(r'<Cookie ([^=]+)=([^ ]+) for .instagram.com/>', cok)
    coki = '; '.join([f"{name}={value}" for name, value in cokie])
    up = posting(tok,coki)
    if "https://www.instagram.com/accounts/suspended/" in str(up):
      print(f"\r[*] Username: {usernam}\n[*] Password: {pas}\n[*] UserAgent: {ua}\n[*] Cookies: {coki}")
      print("[?] Akun Di Nonaktifkan\n")
      
    else:
      print("[*] CREATE AKUN SUKSES             ")
      print(f"\r[*] Username: {usernam}\n[*] Password: {pas}\n[*] UserAgent: {ua}\n[*] Cookies: {coki}")
     # posting
      user = usernam
      cok = coki
      pw = pas
      posting(tok,cok)
      Main2(user,pw, cok)
      print("[+] Berhasil Upload Photo\n")
      open("ok.txt","a").write(usernam+"|"+pas+"|"+coki+"\n")
    ok+=1
  else: 
    print("\r[*] Create Checkpoint             ")
    print("[*] Username: %s\n[*] Password: %s\n[*] UserAgent: %s\n"%(usernam,pas,ua))
    open("cp.txt","a").write(usernam+"|"+pas+"\n")
    cp+=1
  tunggu(3)
def posting(tok,cok):
  try:
    ssi = random.randint(2,46)
    p_pic_s = f'/sdcard/data/a{ssi}.jpg'
    headers = {
      "Host": "www.instagram.com",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36",
      "Accept": "/",
      "Accept-Language": "en-US,en;q=0.5",
      "Accept-Encoding": "gzip, deflate, br",
      "Referer": "https://www.instagram.com",
      "X-CSRFToken": '%s'%(tok), # ganti csrftoken sesuai cookie yang valid
      "X-Instagram-AJAX": "1013618137",
      "X-Requested-With": "XMLHttpRequest",
      "Content-Length": str(p_pic_s),
      "DNT": "1",
      "Connection": "keep-alive",
    }
    files = {'profile_pic': open(p_pic_s,'rb')}
    values = {
      "Content-Disposition": "form-data",
      "name": "profile_pic",
      "filename":"profilepic.jpg",
      "Content-Type": "image/jpeg"
      }

    r = requests.post('https://www.instagram.com/accounts/web_change_profile_picture/', files=files, data=values, headers=headers, cookies={'cookie':cok}).text
   # print(' succes mena')
    return r
    #  open('Create/ok.txt','a').write(usernam+'|'+pas+'|'+coki+"\n")
  except Exception as e:
    print(e)					
def postisng(tok,coki):
  global img
  try:
    p_pic = img# ganti sama alamat file foto yang mau di unggah
    p_pic_s = os.path.getsize(p_pic)
    headers = {
      "Host": "www.instagram.com",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36",
      "Accept": "/",
      "Accept-Language": "en-US,en;q=0.5",
      "Accept-Encoding": "gzip, deflate, br",
      "Referer": "https://www.instagram.com",
      "X-CSRFToken": '%s'%(tok), # ganti csrftoken sesuai cookie yang valid
      "X-Instagram-AJAX": "1013618137",
      "X-Requested-With": "XMLHttpRequest",
      "Content-Length": str(p_pic_s),
      "DNT": "1",
      "Connection": "keep-alive",
    }
    files = {'profile_pic': open(p_pic,'rb')}
    values = {
      "Content-Disposition": "form-data",
      "name": "profile_pic",
      "filename":"profilepic.jpg",
      "Content-Type": "image/jpeg"
      }

    r = requests.post('https://www.instagram.com/accounts/web_change_profile_picture/', files=files, data=values, headers=headers, cookies={'cookie':coki}).text
    return r
    #  open('Create/ok.txt','a').write(usernam+'|'+pas+'|'+coki+"\n")
  except Exception as e:
    print(e)
