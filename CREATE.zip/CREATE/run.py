from data import *
import re,os,sys,bs4,json,random,time,datetime,requests,string
from datetime import datetime
from fake_email import Email
from faker import Faker
from rich import print as prints
from rich.tree import Tree
from bs4 import BeautifulSoup as parser
from random import choice as rc
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m' 
O = '\x1b[1;96m'
N = '\x1b[0m'    
Z = "\033[1;30m"
sir = '\033[41m\x1b[1;97m'
x = '\33[m' # DEFAULT
m = '\x1b[1;91m' #RED +
k = '\033[93m' # KUNING +
h = '\x1b[1;92m' # HIJAU +
hh = '\033[32m' # HIJAU -
u = '\033[95m' # UNGU
kk = '\033[33m' # KUNING -
b = '\33[1;96m' # BIRU -
p = '\x1b[0;34m' # BIRU +
asu = random.choice([m,k,h,u,b])
ok = 0




def jeda(t):
  for x in range(t+1):
#    print(f'\r[ Menunngu ')
    print('\rTunggu %s Detik  Succes Create : %s    '%(str(t),ok),end='');sys.stdout.flush()
    t -= 1
    if t == 0: break
    else: time.sleep(1)

class Main2:
  counter = 1
  def __init__(self, user ,pw,cok):
    self.r = requests.session()
    self.user = user
    self.pw = pw
    self.cok = cok.strip()
  #  bagong = nama_file
#    dpi = depei
    self.step()
    
    
  def step(self):
 #   print
    #print("Sedag Mengaktifkan A2F")
    try:
      req = self.r.get("https://accountscenter.instagram.com/password_and_security/two_factor/",headers=hed,cookies={"cookie":self.cok}).text 
      ID = re.search('"clientID":"(.*?)"',str(req)).group(1)
      
      data = GetData(req)
      data.update({
        'fb_api_caller_class':'RelayModern',
        'fb_api_req_friendly_name':'useFXSettingsTwoFactorGenerateTOTPKeyMutation',
        'variables': json.dumps({"input":{"client_mutation_id":ID,"actor_id":data['av'],"account_id":data['av'],"account_type":"INSTAGRAM","device_id":"device_id_fetch_ig_did","fdid":"device_id_fetch_ig_did"}}),
      'server_timestamps':True,
      'doc_id':'6282672078501565'
      })
      res1 = self.r.post("https://accountscenter.instagram.com/api/graphql/",data=data,headers=header,cookies={"cookie": self.cok})
      key = re.search('"key_text":"(.*?)"',str(res1.text)).group(1)
      xxx = key.replace(" ","")
      otp = self.r.get(f"https://2fa.live/tok/{xxx}").json()["token"]
      self.Auten(otp,req,xxx,key)
    except Exception as e: print(e)
    
      
    
  def Auten(self, otp,req,xxx,key):
    req1 = self.r.get("https://accountscenter.instagram.com/password_and_security/two_factor/",headers=hed,cookies={"cookie":self.cok}).text 
    aid = re.findall('"clientID":"(.*?)"',str(req1))[0]
    data = DataGet(req)
    data.update({
      "fb_api_caller_class":"RelayModern",
      "fb_api_req_friendly_name":"useFXSettingsTwoFactorEnableTOTPMutation",
      "variables": json.dumps({"input":{"client_mutation_id":aid,"actor_id":data["av"],"account_id":data["av"],"account_type":"INSTAGRAM","verification_code":otp,"device_id":"device_id_fetch_ig_did","fdid":"device_id_fetch_ig_did"}}),
      "server_timestamps":True,
      "doc_id":"7032881846733167"
    })
    ps = self.r.post("https://accountscenter.instagram.com/api/graphql/",data=data,headers=head,cookies={"cookie": self.cok})
    if '"success":true' in str(ps.text):
      self.Kode(req1,key, aid)
      time.sleep(5)
    elif '"success":false' in str(ps.text):
      return "gagal\n"
    
  
  def Kode(self,req1, key, aid):
    #print("\r[*] Sedang Menunggu Kode")
    data = KodeGet(req1)
    data.update({
      'fb_api_caller_class': 'RelayModern',
      'fb_api_req_friendly_name': 'useFXSettingsTwoFactorFetchRecoveryCodesMutation',
      'variables': json.dumps({"input":{"client_mutation_id":aid,"actor_id":data['av'],"account_id":data['av'],"account_type":"INSTAGRAM","fdid":"device_id_fetch_ig_did"}}),
      'server_timestamps': True,
      'doc_id': '24140213678960162',
    })
    ps = self.r.post("https://accountscenter.instagram.com/api/graphql/",data=data,headers=headers,cookies={"cookie":self.cok})
    js = ps.json()
    if '"success":true' in str(ps.text):
      recovery_codes = js["data"]["xfb_two_factor_fetch_recovery_codes"]["recovery_codes"]
      codes = "\n".join(code.replace(" ", "\t") for code in recovery_codes)
      key_with_counter = f"{Main2.counter}. {self.user}"
      print('[bold green]succes')
      print(f'[bold green]{key}')
      print(f'[bold green]{codes}')
     # prints(tree)
      with open(f"/sdcard/kontolig.txt", "a") as file: file.write(f"\n{self.user}\n{key}")
  #    print(f"Kode Pemulihan: {recovery_codes}")
      with open(f"/sdcard/ple.txt", "a") as file: file.write(f"{self.cok}\n")
   #   open(f"/sdcard/komen/tumbal.py","a").write(f'{self.cok}\n')
            
      Main2.counter += 1
      #print(f"[*] Key: {key}\n{codes}\n{self.uid}")
      #open("AF2.txt","a").write(key+"\n"+codes+"\n"+self.uid+"\n")
      #ok+=1
    
#if __name__=="__main__":
  #os.system("clear")
 # with open("/sdcard/600.txt","r") as file:
   # dat = file.readlines()
  #  for data in dat:
    #  user, pw, cok = data.split("|")
    #  Main2(user,pw, cok)
    
      
      
