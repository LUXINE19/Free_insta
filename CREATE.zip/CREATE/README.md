
<h6 align="center"> 
  TOOLS AUTO CREATE ACCOUNT INSTAGRAM
</h6>

![Screenshot_20240522-062027](https://github.com/AtsunaID/CreateIG/assets/136549133/47b75ff1-3168-4cb9-a943-d8b61f1e37b4.jpg)

# Languages
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
# IDEs/Editor
<img alt="Visual Studio Code" src="https://img.shields.io/badge/VisualStudioCode-0078d7.svg?style=for-the-badge&logo=visual-studio-code&logoColor=white"/>

# Support 
<h6>
  Sidiq Brewstreet
</h6>
<a href="https://github.com/sidiqbrewstreet" target="_blank">
   	<img alt="sodiqbrewstreet" src="https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white"/>
</a>

### Install Script On Termux

``` 
$ pkg install git 
$ pip install bs4 
$ pip install fake_email 
$ git clone https://github.com/AtsunaID/CreateIG 
$ cd CreateIG 
$ ls 
$ python run.py
``` 
